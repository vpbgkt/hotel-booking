'use client';

import React from 'react';

interface StarRatingProps {
  rating: number;
  maxStars?: number;
  size?: 'sm' | 'md' | 'lg';
  showValue?: boolean;
}

const sizeClasses = {
  sm: 'w-3 h-3',
  md: 'w-4 h-4',
  lg: 'w-5 h-5',
};

export function StarRating({
  rating,
  maxStars = 5,
  size = 'md',
  showValue = false,
}: StarRatingProps) {
  return React.createElement(
    'span',
    { className: 'inline-flex items-center gap-0.5' },
    ...Array.from({ length: maxStars }, (_, i) =>
      React.createElement(
        'svg',
        {
          key: i,
          className: `${sizeClasses[size]} ${
            i < Math.floor(rating)
              ? 'text-yellow-400 fill-current'
              : i < rating
                ? 'text-yellow-400 fill-current opacity-50'
                : 'text-gray-300 fill-current'
          }`,
          viewBox: '0 0 20 20',
          xmlns: 'http://www.w3.org/2000/svg',
        },
        React.createElement('path', {
          d: 'M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z',
        }),
      ),
    ),
    showValue
      ? React.createElement(
          'span',
          { className: 'ml-1 text-sm text-gray-600' },
          rating.toFixed(1),
        )
      : null,
  );
}
