/**
 * Payment Service - BlueStay API
 * 
 * Gateway-agnostic payment service with Razorpay integration.
 * Architecture: Uses a strategy pattern — DemoGateway for dev, 
 * RazorpayGateway for production (Indian payments only).
 */

import { Injectable, Logger, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { randomUUID, createHmac } from 'crypto';
import Razorpay from 'razorpay';
import Stripe from 'stripe';

export interface PaymentGatewayInterface {
  readonly name: string;
  
  createOrder(amount: number, currency: string, metadata?: Record<string, any>): Promise<{
    orderId: string;
    amount: number;
    currency: string;
    gatewayData?: Record<string, any>;
  }>;
  
  verifyPayment(paymentId: string, orderId: string, signature?: string): Promise<{
    verified: boolean;
    gatewayPaymentId: string;
    status: string;
  }>;
  
  processRefund(paymentId: string, amount: number): Promise<{
    refundId: string;
    amount: number;
    status: string;
  }>;
}

/**
 * Demo Payment Gateway
 * Simulates payment processing for development/testing.
 * All payments auto-approve after a brief delay.
 */
class DemoGateway implements PaymentGatewayInterface {
  readonly name = 'DEMO';

  async createOrder(amount: number, currency: string, metadata?: Record<string, any>) {
    const orderId = `demo_order_${randomUUID().slice(0, 12)}`;
    return {
      orderId,
      amount,
      currency,
      gatewayData: {
        gateway: 'DEMO',
        mode: 'test',
        message: 'Demo payment - auto-approves all transactions',
        ...metadata,
      },
    };
  }

  async verifyPayment(paymentId: string, orderId: string) {
    return {
      verified: true,
      gatewayPaymentId: paymentId || `demo_pay_${randomUUID().slice(0, 12)}`,
      status: 'CAPTURED',
    };
  }

  async processRefund(paymentId: string, amount: number) {
    return {
      refundId: `demo_refund_${randomUUID().slice(0, 12)}`,
      amount,
      status: 'REFUNDED',
    };
  }
}

/**
 * Razorpay Payment Gateway
 * Real payment processing for Indian payments.
 * Supports UPI, Cards, Net Banking, Wallets via Razorpay Checkout.
 * Amounts are in paise (1 INR = 100 paise).
 */
class RazorpayGateway implements PaymentGatewayInterface {
  readonly name = 'RAZORPAY';
  private razorpay: InstanceType<typeof Razorpay>;
  private keyId: string;
  private keySecret: string;

  constructor() {
    this.keyId = process.env.RAZORPAY_KEY_ID || '';
    this.keySecret = process.env.RAZORPAY_KEY_SECRET || '';
    this.razorpay = new Razorpay({
      key_id: this.keyId,
      key_secret: this.keySecret,
    });
  }

  async createOrder(amount: number, currency: string, metadata?: Record<string, any>) {
    const amountInPaise = Math.round(amount * 100);
    const receipt = `rcpt_${randomUUID().slice(0, 12)}`;

    const order = await this.razorpay.orders.create({
      amount: amountInPaise,
      currency: currency || 'INR',
      receipt,
      notes: metadata ? {
        bookingId: metadata.bookingId || '',
        bookingNumber: metadata.bookingNumber || '',
        hotelName: metadata.hotelName || '',
      } : undefined,
    });

    return {
      orderId: order.id,
      amount,
      currency: order.currency,
      gatewayData: {
        gateway: 'RAZORPAY',
        razorpayKeyId: this.keyId,
        razorpayOrderId: order.id,
        amount: amountInPaise,
        currency: order.currency,
        name: metadata?.hotelName || 'BlueStay',
        description: `Booking ${metadata?.bookingNumber || ''}`,
        prefill: metadata?.prefill || {},
      },
    };
  }

  async verifyPayment(paymentId: string, orderId: string, signature?: string) {
    if (!signature) {
      return { verified: false, gatewayPaymentId: paymentId, status: 'FAILED' };
    }

    // Razorpay signature verification: HMAC SHA256 of "orderId|paymentId"
    const expectedSignature = createHmac('sha256', this.keySecret)
      .update(`${orderId}|${paymentId}`)
      .digest('hex');

    const verified = expectedSignature === signature;

    return {
      verified,
      gatewayPaymentId: paymentId,
      status: verified ? 'CAPTURED' : 'FAILED',
    };
  }

  async processRefund(paymentId: string, amount: number) {
    const amountInPaise = Math.round(amount * 100);

    const refund = await this.razorpay.payments.refund(paymentId, {
      amount: amountInPaise,
    });

    return {
      refundId: refund.id,
      amount,
      status: refund.status === 'processed' ? 'REFUNDED' : 'PENDING',
    };
  }
}

/**
 * Stripe Payment Gateway
 * International payment processing.
 * Amounts are in smallest currency unit (e.g. paise for INR, cents for USD).
 */
class StripeGateway implements PaymentGatewayInterface {
  readonly name = 'STRIPE';
  private stripe: Stripe;

  constructor() {
    this.stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
      apiVersion: '2026-02-25.clover',
    });
  }

  async createOrder(amount: number, currency: string, metadata?: Record<string, any>) {
    const amountInSmallest = Math.round(amount * 100);

    const session = await this.stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: (currency || 'INR').toLowerCase(),
            product_data: {
              name: `Booking ${metadata?.bookingNumber || ''}`,
              description: `${metadata?.hotelName || 'BlueStay'} - ${metadata?.roomType || 'Room'}`,
            },
            unit_amount: amountInSmallest,
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${process.env.WEB_URL || 'http://localhost:3000'}/booking/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.WEB_URL || 'http://localhost:3000'}/booking/cancel`,
      metadata: metadata ? {
        bookingId: metadata.bookingId || '',
        bookingNumber: metadata.bookingNumber || '',
      } : undefined,
    });

    return {
      orderId: session.id,
      amount,
      currency: (currency || 'INR').toUpperCase(),
      gatewayData: {
        gateway: 'STRIPE',
        sessionId: session.id,
        sessionUrl: session.url,
      },
    };
  }

  async verifyPayment(paymentId: string, orderId: string) {
    const session = await this.stripe.checkout.sessions.retrieve(orderId);
    const verified = session.payment_status === 'paid';

    return {
      verified,
      gatewayPaymentId: (session.payment_intent as string) || paymentId,
      status: verified ? 'CAPTURED' : 'FAILED',
    };
  }

  async processRefund(paymentId: string, amount: number) {
    const amountInSmallest = Math.round(amount * 100);

    const refund = await this.stripe.refunds.create({
      payment_intent: paymentId,
      amount: amountInSmallest,
    });

    return {
      refundId: refund.id,
      amount,
      status: refund.status === 'succeeded' ? 'REFUNDED' : 'PENDING',
    };
  }
}

@Injectable()
export class PaymentService {
  private readonly logger = new Logger(PaymentService.name);
  private gateway: PaymentGatewayInterface;

  constructor(private readonly prisma: PrismaService) {
    // Auto-select gateway based on env config
    if (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
      this.gateway = new RazorpayGateway();
      this.logger.log('Payment service initialized with RAZORPAY gateway');
    } else if (process.env.STRIPE_SECRET_KEY) {
      this.gateway = new StripeGateway();
      this.logger.log('Payment service initialized with STRIPE gateway');
    } else {
      this.gateway = new DemoGateway();
      this.logger.log('Payment service initialized with DEMO gateway (set RAZORPAY_KEY_ID & RAZORPAY_KEY_SECRET or STRIPE_SECRET_KEY for real payments)');
    }
  }

  /**
   * Initiate a payment for a booking
   */
  async initiatePayment(bookingId: string, method: string) {
    const booking = await this.prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        hotel: { select: { id: true, name: true } },
        roomType: { select: { id: true, name: true } },
      },
    });

    if (!booking) {
      throw new NotFoundException(`Booking ${bookingId} not found`);
    }

    if (booking.paymentStatus === 'PAID') {
      throw new BadRequestException('This booking has already been paid');
    }

    // Create order with the gateway
    const order = await this.gateway.createOrder(
      booking.totalAmount,
      'INR',
      {
        bookingId: booking.id,
        bookingNumber: booking.bookingNumber,
        hotelName: booking.hotel.name,
        roomType: booking.roomType.name,
      }
    );

    // Create payment record
    const payment = await this.prisma.payment.create({
      data: {
        bookingId: booking.id,
        gateway: this.gateway.name as any,
        gatewayOrderId: order.orderId,
        amount: booking.totalAmount,
        currency: 'INR',
        status: 'CREATED',
        metadata: order.gatewayData as any,
      },
    });

    this.logger.log(`Payment initiated for booking ${booking.bookingNumber}: ${payment.id} via ${this.gateway.name}`);

    return {
      paymentId: payment.id,
      orderId: order.orderId,
      amount: booking.totalAmount,
      currency: 'INR',
      gateway: this.gateway.name,
      bookingNumber: booking.bookingNumber,
      gatewayData: order.gatewayData,
    };
  }

  /**
   * Confirm/verify a payment and update booking status
   */
  async confirmPayment(
    paymentId: string, 
    gatewayPaymentId?: string, 
    gatewaySignature?: string
  ) {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId },
      include: { booking: true },
    });

    if (!payment) {
      throw new NotFoundException(`Payment ${paymentId} not found`);
    }

    if (payment.status === 'CAPTURED') {
      return {
        success: true,
        message: 'Payment already confirmed',
        bookingId: payment.bookingId,
        bookingNumber: payment.booking.bookingNumber,
      };
    }

    // Verify with gateway
    const verification = await this.gateway.verifyPayment(
      gatewayPaymentId || `demo_pay_${randomUUID().slice(0, 8)}`,
      payment.gatewayOrderId || '',
      gatewaySignature
    );

    if (!verification.verified) {
      // Mark payment as failed
      await this.prisma.payment.update({
        where: { id: paymentId },
        data: { status: 'FAILED' },
      });

      await this.prisma.booking.update({
        where: { id: payment.bookingId },
        data: { paymentStatus: 'FAILED' },
      });

      return {
        success: false,
        message: 'Payment verification failed',
        bookingId: payment.bookingId,
      };
    }

    // Update payment and booking in a transaction
    const result = await this.prisma.$transaction(async (tx) => {
      // Update payment
      await tx.payment.update({
        where: { id: paymentId },
        data: {
          status: 'CAPTURED',
          gatewayPaymentId: verification.gatewayPaymentId,
          metadata: {
            ...(payment.metadata as Record<string, any> || {}),
            verifiedAt: new Date().toISOString(),
          },
        },
      });

      // Update booking
      const updatedBooking = await tx.booking.update({
        where: { id: payment.bookingId },
        data: {
          paymentStatus: 'PAID',
          status: 'CONFIRMED',
        },
        include: {
          hotel: {
            select: { id: true, name: true, slug: true, address: true, city: true, phone: true },
          },
          roomType: {
            select: { id: true, name: true, slug: true, images: true },
          },
        },
      });

      return updatedBooking;
    });

    this.logger.log(`Payment confirmed for booking ${payment.booking.bookingNumber}`);

    return {
      success: true,
      message: 'Payment confirmed. Booking is now confirmed.',
      bookingId: result.id,
      bookingNumber: result.bookingNumber,
      booking: result,
    };
  }

  /**
   * Process refund for a cancelled booking
   */
  async processRefund(bookingId: string, amount?: number) {
    const booking = await this.prisma.booking.findUnique({
      where: { id: bookingId },
      include: { payments: true },
    });

    if (!booking) {
      throw new NotFoundException(`Booking ${bookingId} not found`);
    }

    const capturedPayment = booking.payments.find(p => p.status === 'CAPTURED');
    if (!capturedPayment) {
      throw new BadRequestException('No captured payment found for this booking');
    }

    const refundAmount = amount ?? booking.totalAmount;

    const refundResult = await this.gateway.processRefund(
      capturedPayment.gatewayPaymentId || '',
      refundAmount
    );

    // Update payment record
    await this.prisma.payment.update({
      where: { id: capturedPayment.id },
      data: {
        status: refundAmount >= booking.totalAmount ? 'REFUNDED' : 'CAPTURED',
        refundAmount: { increment: refundAmount },
        refundId: refundResult.refundId,
      },
    });

    // Update booking
    await this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        paymentStatus: refundAmount >= booking.totalAmount ? 'REFUNDED' : 'PARTIALLY_REFUNDED',
      },
    });

    this.logger.log(`Refund processed for booking ${booking.bookingNumber}: ₹${refundAmount}`);

    return {
      success: true,
      refundId: refundResult.refundId,
      amount: refundAmount,
      message: `Refund of ₹${refundAmount} processed successfully`,
    };
  }

  /**
   * Get payment by ID
   */
  async getPaymentById(id: string) {
    return this.prisma.payment.findUnique({
      where: { id },
      include: { booking: true },
    });
  }

  /**
   * Get payments for a booking
   */
  async getPaymentsByBooking(bookingId: string) {
    return this.prisma.payment.findMany({
      where: { bookingId },
      orderBy: { createdAt: 'desc' },
    });
  }
}
